The number is for correspondent ICO in the follow:
0. 3D Printer Ready
1. Heating...
2. Printing...
3. Printing Done
4. In The Pause
5. Card Inserted
6. Card Removed
7. Heating Done
8. Cool Down